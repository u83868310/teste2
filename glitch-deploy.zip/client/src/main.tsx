import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Import Remix icon CSS for icons
const remixIconsLink = document.createElement('link');
remixIconsLink.href = "https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css";
remixIconsLink.rel = "stylesheet";
document.head.appendChild(remixIconsLink);

// Set page title
document.title = "StreamFlix - Filmes, Séries e Canais";

// Add custom styles
const styleElement = document.createElement('style');
styleElement.textContent = `
  body {
    background-color: #141414;
    color: #e5e5e5;
    font-family: 'Inter', sans-serif;
  }
  
  .font-heading {
    font-family: 'Poppins', sans-serif;
  }
  
  .content-card:hover {
    transform: scale(1.05);
    transition: transform 0.3s ease;
  }
  
  .category-slider {
    scrollbar-width: none;
  }
  
  .category-slider::-webkit-scrollbar {
    display: none;
  }
  
  .scrollbar-hide::-webkit-scrollbar {
    display: none;
  }
  
  .scrollbar-hide {
    -ms-overflow-style: none;
    scrollbar-width: none;
  }
`;
document.head.appendChild(styleElement);

createRoot(document.getElementById("root")!).render(<App />);
