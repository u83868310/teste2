# IPTV Streaming Platform para Glitch

Esta é uma plataforma de streaming IPTV otimizada para rodar no Glitch. Ela permite visualizar canais IPTV, filmes e séries diretamente no navegador.

## Como Iniciar

1. O script `start.sh` será executado automaticamente quando você importar o projeto no Glitch
2. Aguarde a instalação das dependências e inicialização do servidor
3. O Glitch irá mostrar uma URL para acessar seu aplicativo quando estiver pronto

## Recursos

- Interface responsiva para desktop e mobile
- Suporte para streams HLS via proxy
- Carregamento automático de lista IPTV (local)
- Categorização automática de conteúdo
- Reprodução de mídia via player HLS integrado

## Solução de Problemas

- Se encontrar problemas, verifique os logs no console do Glitch
- A importação da lista IPTV pode levar alguns minutos na primeira execução
- O proxy de streaming pode não funcionar para alguns canais devido a restrições de CORS

## Customização

Para personalizar a plataforma:

1. Edite `theme.json` para mudar as cores e aparência
2. Modifique os componentes em `client/src/components`
3. Atualize a lógica de backend em `server/routes.ts`

## Observações

O Glitch tem limites de recursos, portanto:
- A lista IPTV foi limitada a 500 itens
- O aplicativo pode hibernar após períodos de inatividade
- Recomenda-se fazer um "Boost" no seu projeto Glitch para melhor desempenho
